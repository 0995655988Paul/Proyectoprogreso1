const imagen = document.querySelector(".hero__imagen");
const siguiente = document.querySelector("#siguiente");
const anterior = document.querySelector("#anterior");

const descripciones = [
  "Mesa de madera con sillas blancas y una planta",
  "Sillas de colores amarillo y verde",
  "Silla negra plegable"
  

];
const titulo = document.querySelector(".hero__titulo");
const parrafo = document.querySelector(".hero__descripcion");

const titulos = [
  "Discover innovative ways to decorate",
  "We are available all across the globe",
  "Manufactured with the best materials"
];

const parrafos = [
  "We provide unmatched quality, comfort, and style for property owners " +
  "across the country. Our experts combine form and function in bringing " +
  "your vision to life. Create a room in your own style with our collection " +
  "and make your property a reflection of you and what you love.",

  "With stores all over the world, it’s easy for you to find furniture " +
  "for your home or place of business. Locally, we’re in most major cities " +
  "throughout the country. Find the branch nearest you using our store " +
  "locator. Any questions? Don’t hesitate to contact us today.",

  "Our modern furniture store provide a high level of quality. Our company " +
  "has invested in advanced technology to ensure that every product is " +
  "made as perfect and as consistent as possible. With three decades of " +
  "experience in this industry, we understand what customers want for " +
  "their home and office."
];

let numero = 1;

function mostrarImagen() {
  imagen.src = "assets/desktop-hero-" + numero + ".jpg";
  imagen.alt = descripciones[numero - 1];
  titulo.textContent = titulos[numero - 1];
    parrafo.textContent = parrafos[numero - 1];

  if (numero === 1) {
    imagen.style.transform = "scaleX(-1)";
  } else {
    imagen.style.transform = "none";
  }
}

siguiente.addEventListener("click", function () {
  numero = numero + 1;

  if (numero > 3) {
    numero = 1;
  }

  mostrarImagen();
});

anterior.addEventListener("click", function () {
  numero = numero - 1;

  if (numero < 1) {
    numero = 3;
  }

  mostrarImagen();
});

const botonMenu = document.querySelector("#menu-boton");
const encabezado = document.querySelector(".header");

botonMenu.addEventListener("click", function () {
  const abierto = encabezado.classList.toggle("header--abierto");

  botonMenu.setAttribute("aria-expanded", abierto);

  if (abierto) {
    botonMenu.textContent = "×";
    botonMenu.setAttribute("aria-label", "Cerrar menú");
  } else {
    botonMenu.textContent = "☰";
    botonMenu.setAttribute("aria-label", "Abrir menú");
  }
});